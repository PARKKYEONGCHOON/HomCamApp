import http from "http";
//import WebSocket from "ws";
import express from "express";
import Socketio from "socket.io";
import { Socket } from "socket.io";
import { type } from "os";
import { event } from "socket.io-stream/lib/socket";

const app = express();

app.set("view engine", "pug");
app.set("views", __dirname + "/views");
app.use("/public", express.static(__dirname + "/public"));
app.get("/", (_, res) => res.render("home"));
app.get("/*", (_, res) => res.render("/"));

const handleListen = () => console.log('Listening on http://localhost:3000');

const httpServer = http.createServer(app);
//const wss = new WebSocket.Server( { server } );
const wsServer = Socketio(httpServer);



wsServer.on("connection", socket => {

    socket["nickname"] = "Anon";

    socket.onAny((event) => {
        console.log(`${event}`);
    });

    socket.on('enter_room', (roomName, done) => {
        socket.join(roomName);
        done();
        socket.to(roomName).emit("welcome", socket.nickname);
    });

    socket.on("disconnecting", () => {
        socket.rooms.forEach((room) => socket.to(room).emit("bye", socket.nickname));
    });

    socket.on("new_message", (msg, room, done) => {
        socket.to(room).emit("new_message", `${socket.nickname}: ${msg}`);
        done();
    });

    socket.on("nickname", (nickname) => (socket["nickname"] = nickname));

});

/*const sockets = [];

function handleConnection(socket) {
    console.log(socket);
}

function onSocketClose() {
    console.log("close");
}

function onSocketMessage(message) {
    console.log(message);
}

wss.on("connection", (socket) =>  {
    sockets.push(socket);
    socket["nickName"] = "Anon";
    socket.on("close", onSocketClose)
    socket.on("message", (msg) => {
        const message = JSON.parse(msg);
        switch (message.type) {
            case "new_message":
                sockets.forEach((aSocket) => aSocket.send(`${socket.nickName}: ${message.payload}`));
            case "nickName":
                socket["nickName"] = message.payload;
        }
        
    });
    
});
*/
httpServer.listen(3000, handleListen);

