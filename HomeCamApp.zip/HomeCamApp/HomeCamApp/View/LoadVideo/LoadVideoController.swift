//
//  LoadVideoController.swift
//  HomeCamApp
//
//  Created by 박경춘 on 2023/04/21.
//

import Foundation
import UIKit

class LoadVideoController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewInit()
        
    }
    
    func viewInit() {
        
        navigationItem.title = "영상 불러오기"
        
    }
    
}
