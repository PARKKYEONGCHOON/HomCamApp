//
//  LiveViewController.swift
//  HomeCamApp
//
//  Created by 박경춘 on 2023/04/21.
//

import Foundation
import UIKit
import WebKit
import SnapKit

class LiveViewController: UIViewController {
    
    let webkitView = WKWebView()
    
    
    private lazy var CaptureButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 15
        button.backgroundColor = .blue
        button.setTitle("영상 캡처", for: .normal)
                
        return button
    }()
    private lazy var SaveButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 15
        button.backgroundColor = .blue
        button.setTitle("영상 저장", for: .normal)
        
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let myURL = URL(string:"https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        self.webkitView.load(myRequest)
        
        viewInit()
        
        
    }
    
    func viewInit() {
        
        navigationItem.title = "실시간 영상"
        
        let buttonStackView = UIStackView(arrangedSubviews: [CaptureButton, SaveButton])
        buttonStackView.axis = .horizontal
        buttonStackView.distribution = .fillEqually
        buttonStackView.spacing = 8.0
        
        [webkitView, buttonStackView].forEach {
            self.view.addSubview($0)
        }
        
        webkitView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).inset(16.0)
            $0.leading.trailing.equalToSuperview()
            $0.height.equalTo(UIScreen.main.bounds.height / 2)
        }
        
        buttonStackView.snp.makeConstraints {
            $0.top.equalTo(webkitView.snp.bottom).offset(16.0)
            $0.leading.trailing.equalToSuperview().inset(16.0)
        }
        
    }
    
}




extension LiveViewController: WKUIDelegate {
    
}
