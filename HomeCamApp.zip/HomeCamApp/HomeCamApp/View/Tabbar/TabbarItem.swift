//
//  TabBarItem.swift
//  Twitter
//
//  Created by 박경춘 on 2023/04/02.
//

import UIKit

enum TabBarItem: CaseIterable {
    
    case LiveStreaming
    case LoadVideo
    case LoadImage
    
    var title : String {
        switch self {
        case .LiveStreaming:
            return "실시간 영상"
        
        case .LoadVideo:
            return "저장된 동영상"
            
        case .LoadImage:
            return "저장된 이미지"
        }
        
    
    }
    
    var icon: (default: UIImage?, selected: UIImage?) {
        
        switch self {
        case .LiveStreaming:
            return (UIImage(systemName: "video"), UIImage(systemName: "video.fill"))
        case .LoadVideo:
            return (UIImage(systemName: "videoprojector"), UIImage(systemName: "videoprojector.fill"))
        case .LoadImage:
            return (UIImage(systemName: "camera"), UIImage(systemName: "camera.fill"))
        }
        
    }
    
    var viewController: UIViewController {
        switch self {
        case .LiveStreaming:
            return UINavigationController(rootViewController: LiveViewController())
        case .LoadVideo:
            return UINavigationController(rootViewController: LoadVideoController())
        case .LoadImage:
            return UINavigationController(rootViewController: LoadImageController())
        }
    }
    
}
